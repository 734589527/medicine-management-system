﻿namespace 医药管理系统.Limits
{
    partial class limitList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gupBox = new System.Windows.Forms.GroupBox();
            this.tbx = new System.Windows.Forms.TextBox();
            this.submitUp = new System.Windows.Forms.Button();
            this.idLab = new System.Windows.Forms.Label();
            this.delete = new System.Windows.Forms.Button();
            this.roleCob = new System.Windows.Forms.ComboBox();
            this.edeit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.updateVerify = new System.Windows.Forms.CheckBox();
            this.deleteVerify = new System.Windows.Forms.CheckBox();
            this.VerifyInfo = new System.Windows.Forms.CheckBox();
            this.addVerify = new System.Windows.Forms.CheckBox();
            this.stoWarn = new System.Windows.Forms.CheckBox();
            this.readyStoOut = new System.Windows.Forms.CheckBox();
            this.stoOut = new System.Windows.Forms.CheckBox();
            this.adjustSto = new System.Windows.Forms.CheckBox();
            this.stoIn = new System.Windows.Forms.CheckBox();
            this.selectSto = new System.Windows.Forms.CheckBox();
            this.rolInfo = new System.Windows.Forms.CheckBox();
            this.updateRol = new System.Windows.Forms.CheckBox();
            this.addRol = new System.Windows.Forms.CheckBox();
            this.deleteRol = new System.Windows.Forms.CheckBox();
            this.reGoodsGra = new System.Windows.Forms.CheckBox();
            this.stoOutGra = new System.Windows.Forms.CheckBox();
            this.reOrderGra = new System.Windows.Forms.CheckBox();
            this.stoInGra = new System.Windows.Forms.CheckBox();
            this.saleGra = new System.Windows.Forms.CheckBox();
            this.stfInfo = new System.Windows.Forms.CheckBox();
            this.commInfo = new System.Windows.Forms.CheckBox();
            this.cusInfo = new System.Windows.Forms.CheckBox();
            this.addSale = new System.Windows.Forms.CheckBox();
            this.updateStf = new System.Windows.Forms.CheckBox();
            this.addStf = new System.Windows.Forms.CheckBox();
            this.deleteStf = new System.Windows.Forms.CheckBox();
            this.updateComm = new System.Windows.Forms.CheckBox();
            this.addComm = new System.Windows.Forms.CheckBox();
            this.deleteComm = new System.Windows.Forms.CheckBox();
            this.updateCus = new System.Windows.Forms.CheckBox();
            this.roleManage = new System.Windows.Forms.CheckBox();
            this.verifyCommManage = new System.Windows.Forms.CheckBox();
            this.graphManage = new System.Windows.Forms.CheckBox();
            this.saleManage = new System.Windows.Forms.CheckBox();
            this.staffManage = new System.Windows.Forms.CheckBox();
            this.commodityManage = new System.Windows.Forms.CheckBox();
            this.customerManage = new System.Windows.Forms.CheckBox();
            this.stockManage = new System.Windows.Forms.CheckBox();
            this.selectSale = new System.Windows.Forms.CheckBox();
            this.reOrder = new System.Windows.Forms.CheckBox();
            this.addCus = new System.Windows.Forms.CheckBox();
            this.deleteCus = new System.Windows.Forms.CheckBox();
            this.reGoods = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gupBox
            // 
            this.gupBox.Controls.Add(this.tbx);
            this.gupBox.Controls.Add(this.submitUp);
            this.gupBox.Controls.Add(this.idLab);
            this.gupBox.Controls.Add(this.delete);
            this.gupBox.Controls.Add(this.roleCob);
            this.gupBox.Controls.Add(this.edeit);
            this.gupBox.Controls.Add(this.groupBox1);
            this.gupBox.Controls.Add(this.label1);
            this.gupBox.Location = new System.Drawing.Point(27, 12);
            this.gupBox.Name = "gupBox";
            this.gupBox.Size = new System.Drawing.Size(860, 427);
            this.gupBox.TabIndex = 1;
            this.gupBox.TabStop = false;
            this.gupBox.Text = "角色记录项";
            // 
            // tbx
            // 
            this.tbx.Location = new System.Drawing.Point(361, 19);
            this.tbx.Name = "tbx";
            this.tbx.Size = new System.Drawing.Size(100, 21);
            this.tbx.TabIndex = 15;
            // 
            // submitUp
            // 
            this.submitUp.Location = new System.Drawing.Point(386, 380);
            this.submitUp.Name = "submitUp";
            this.submitUp.Size = new System.Drawing.Size(75, 23);
            this.submitUp.TabIndex = 14;
            this.submitUp.Text = "确定";
            this.submitUp.UseVisualStyleBackColor = true;
            this.submitUp.Click += new System.EventHandler(this.submitUp_Click);
            // 
            // idLab
            // 
            this.idLab.AutoSize = true;
            this.idLab.Location = new System.Drawing.Point(172, 23);
            this.idLab.Name = "idLab";
            this.idLab.Size = new System.Drawing.Size(0, 12);
            this.idLab.TabIndex = 13;
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(443, 380);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 12;
            this.delete.Text = "删除";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // roleCob
            // 
            this.roleCob.FormattingEnabled = true;
            this.roleCob.Location = new System.Drawing.Point(361, 20);
            this.roleCob.Name = "roleCob";
            this.roleCob.Size = new System.Drawing.Size(121, 20);
            this.roleCob.TabIndex = 1;
            this.roleCob.SelectedIndexChanged += new System.EventHandler(this.roleCob_SelectedIndexChanged);
            // 
            // edeit
            // 
            this.edeit.Location = new System.Drawing.Point(322, 380);
            this.edeit.Name = "edeit";
            this.edeit.Size = new System.Drawing.Size(75, 23);
            this.edeit.TabIndex = 11;
            this.edeit.Text = "编辑";
            this.edeit.UseVisualStyleBackColor = true;
            this.edeit.Click += new System.EventHandler(this.edeit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.updateVerify);
            this.groupBox1.Controls.Add(this.deleteVerify);
            this.groupBox1.Controls.Add(this.VerifyInfo);
            this.groupBox1.Controls.Add(this.addVerify);
            this.groupBox1.Controls.Add(this.stoWarn);
            this.groupBox1.Controls.Add(this.readyStoOut);
            this.groupBox1.Controls.Add(this.stoOut);
            this.groupBox1.Controls.Add(this.adjustSto);
            this.groupBox1.Controls.Add(this.stoIn);
            this.groupBox1.Controls.Add(this.selectSto);
            this.groupBox1.Controls.Add(this.rolInfo);
            this.groupBox1.Controls.Add(this.updateRol);
            this.groupBox1.Controls.Add(this.addRol);
            this.groupBox1.Controls.Add(this.deleteRol);
            this.groupBox1.Controls.Add(this.reGoodsGra);
            this.groupBox1.Controls.Add(this.stoOutGra);
            this.groupBox1.Controls.Add(this.reOrderGra);
            this.groupBox1.Controls.Add(this.stoInGra);
            this.groupBox1.Controls.Add(this.saleGra);
            this.groupBox1.Controls.Add(this.stfInfo);
            this.groupBox1.Controls.Add(this.commInfo);
            this.groupBox1.Controls.Add(this.cusInfo);
            this.groupBox1.Controls.Add(this.addSale);
            this.groupBox1.Controls.Add(this.updateStf);
            this.groupBox1.Controls.Add(this.addStf);
            this.groupBox1.Controls.Add(this.deleteStf);
            this.groupBox1.Controls.Add(this.updateComm);
            this.groupBox1.Controls.Add(this.addComm);
            this.groupBox1.Controls.Add(this.deleteComm);
            this.groupBox1.Controls.Add(this.updateCus);
            this.groupBox1.Controls.Add(this.roleManage);
            this.groupBox1.Controls.Add(this.verifyCommManage);
            this.groupBox1.Controls.Add(this.graphManage);
            this.groupBox1.Controls.Add(this.saleManage);
            this.groupBox1.Controls.Add(this.staffManage);
            this.groupBox1.Controls.Add(this.commodityManage);
            this.groupBox1.Controls.Add(this.customerManage);
            this.groupBox1.Controls.Add(this.stockManage);
            this.groupBox1.Controls.Add(this.selectSale);
            this.groupBox1.Controls.Add(this.reOrder);
            this.groupBox1.Controls.Add(this.addCus);
            this.groupBox1.Controls.Add(this.deleteCus);
            this.groupBox1.Controls.Add(this.reGoods);
            this.groupBox1.Location = new System.Drawing.Point(42, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(759, 311);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "权限记录项";
            // 
            // updateVerify
            // 
            this.updateVerify.AutoSize = true;
            this.updateVerify.Location = new System.Drawing.Point(581, 244);
            this.updateVerify.Name = "updateVerify";
            this.updateVerify.Size = new System.Drawing.Size(96, 16);
            this.updateVerify.TabIndex = 47;
            this.updateVerify.Text = "修改检验信息";
            this.updateVerify.UseVisualStyleBackColor = true;
            // 
            // deleteVerify
            // 
            this.deleteVerify.AutoSize = true;
            this.deleteVerify.Location = new System.Drawing.Point(581, 223);
            this.deleteVerify.Name = "deleteVerify";
            this.deleteVerify.Size = new System.Drawing.Size(96, 16);
            this.deleteVerify.TabIndex = 46;
            this.deleteVerify.Text = "删除检验信息";
            this.deleteVerify.UseVisualStyleBackColor = true;
            // 
            // VerifyInfo
            // 
            this.VerifyInfo.AutoSize = true;
            this.VerifyInfo.Location = new System.Drawing.Point(562, 202);
            this.VerifyInfo.Name = "VerifyInfo";
            this.VerifyInfo.Size = new System.Drawing.Size(96, 16);
            this.VerifyInfo.TabIndex = 45;
            this.VerifyInfo.Text = "检验信息管理";
            this.VerifyInfo.UseVisualStyleBackColor = true;
            this.VerifyInfo.Click += new System.EventHandler(this.VerifyInfo_Click);
            // 
            // addVerify
            // 
            this.addVerify.AutoSize = true;
            this.addVerify.Location = new System.Drawing.Point(562, 180);
            this.addVerify.Name = "addVerify";
            this.addVerify.Size = new System.Drawing.Size(96, 16);
            this.addVerify.TabIndex = 44;
            this.addVerify.Text = "添加检验信息";
            this.addVerify.UseVisualStyleBackColor = true;
            // 
            // stoWarn
            // 
            this.stoWarn.AutoSize = true;
            this.stoWarn.Location = new System.Drawing.Point(99, 284);
            this.stoWarn.Name = "stoWarn";
            this.stoWarn.Size = new System.Drawing.Size(72, 16);
            this.stoWarn.TabIndex = 31;
            this.stoWarn.Text = "库存预警";
            this.stoWarn.UseVisualStyleBackColor = true;
            // 
            // readyStoOut
            // 
            this.readyStoOut.AutoSize = true;
            this.readyStoOut.Location = new System.Drawing.Point(99, 263);
            this.readyStoOut.Name = "readyStoOut";
            this.readyStoOut.Size = new System.Drawing.Size(72, 16);
            this.readyStoOut.TabIndex = 30;
            this.readyStoOut.Text = "出库审核";
            this.readyStoOut.UseVisualStyleBackColor = true;
            // 
            // stoOut
            // 
            this.stoOut.AutoSize = true;
            this.stoOut.Location = new System.Drawing.Point(99, 178);
            this.stoOut.Name = "stoOut";
            this.stoOut.Size = new System.Drawing.Size(72, 16);
            this.stoOut.TabIndex = 26;
            this.stoOut.Text = "出库管理";
            this.stoOut.UseVisualStyleBackColor = true;
            // 
            // adjustSto
            // 
            this.adjustSto.AutoSize = true;
            this.adjustSto.Location = new System.Drawing.Point(99, 241);
            this.adjustSto.Name = "adjustSto";
            this.adjustSto.Size = new System.Drawing.Size(72, 16);
            this.adjustSto.TabIndex = 29;
            this.adjustSto.Text = "库存盘点";
            this.adjustSto.UseVisualStyleBackColor = true;
            // 
            // stoIn
            // 
            this.stoIn.AutoSize = true;
            this.stoIn.Location = new System.Drawing.Point(99, 199);
            this.stoIn.Name = "stoIn";
            this.stoIn.Size = new System.Drawing.Size(72, 16);
            this.stoIn.TabIndex = 27;
            this.stoIn.Text = "入库管理";
            this.stoIn.UseVisualStyleBackColor = true;
            // 
            // selectSto
            // 
            this.selectSto.AutoSize = true;
            this.selectSto.Location = new System.Drawing.Point(99, 221);
            this.selectSto.Name = "selectSto";
            this.selectSto.Size = new System.Drawing.Size(72, 16);
            this.selectSto.TabIndex = 28;
            this.selectSto.Text = "查看库存";
            this.selectSto.UseVisualStyleBackColor = true;
            // 
            // rolInfo
            // 
            this.rolInfo.AutoSize = true;
            this.rolInfo.Location = new System.Drawing.Point(562, 73);
            this.rolInfo.Name = "rolInfo";
            this.rolInfo.Size = new System.Drawing.Size(96, 16);
            this.rolInfo.TabIndex = 21;
            this.rolInfo.Text = "角色信息管理";
            this.rolInfo.UseVisualStyleBackColor = true;
            this.rolInfo.Click += new System.EventHandler(this.rolInfo_Click);
            // 
            // updateRol
            // 
            this.updateRol.AutoSize = true;
            this.updateRol.Location = new System.Drawing.Point(581, 120);
            this.updateRol.Name = "updateRol";
            this.updateRol.Size = new System.Drawing.Size(96, 16);
            this.updateRol.TabIndex = 24;
            this.updateRol.Text = "修改角色信息";
            this.updateRol.UseVisualStyleBackColor = true;
            // 
            // addRol
            // 
            this.addRol.AutoSize = true;
            this.addRol.Location = new System.Drawing.Point(562, 51);
            this.addRol.Name = "addRol";
            this.addRol.Size = new System.Drawing.Size(96, 16);
            this.addRol.TabIndex = 20;
            this.addRol.Text = "添加角色信息";
            this.addRol.UseVisualStyleBackColor = true;
            // 
            // deleteRol
            // 
            this.deleteRol.AutoSize = true;
            this.deleteRol.Location = new System.Drawing.Point(581, 95);
            this.deleteRol.Name = "deleteRol";
            this.deleteRol.Size = new System.Drawing.Size(96, 16);
            this.deleteRol.TabIndex = 22;
            this.deleteRol.Text = "删除角色信息";
            this.deleteRol.UseVisualStyleBackColor = true;
            // 
            // reGoodsGra
            // 
            this.reGoodsGra.AutoSize = true;
            this.reGoodsGra.Location = new System.Drawing.Point(259, 265);
            this.reGoodsGra.Name = "reGoodsGra";
            this.reGoodsGra.Size = new System.Drawing.Size(72, 16);
            this.reGoodsGra.TabIndex = 37;
            this.reGoodsGra.Text = "退货报表";
            this.reGoodsGra.UseVisualStyleBackColor = true;
            // 
            // stoOutGra
            // 
            this.stoOutGra.AutoSize = true;
            this.stoOutGra.Location = new System.Drawing.Point(259, 180);
            this.stoOutGra.Name = "stoOutGra";
            this.stoOutGra.Size = new System.Drawing.Size(72, 16);
            this.stoOutGra.TabIndex = 33;
            this.stoOutGra.Text = "出库报表";
            this.stoOutGra.UseVisualStyleBackColor = true;
            // 
            // reOrderGra
            // 
            this.reOrderGra.AutoSize = true;
            this.reOrderGra.Location = new System.Drawing.Point(259, 243);
            this.reOrderGra.Name = "reOrderGra";
            this.reOrderGra.Size = new System.Drawing.Size(72, 16);
            this.reOrderGra.TabIndex = 36;
            this.reOrderGra.Text = "退单报表";
            this.reOrderGra.UseVisualStyleBackColor = true;
            // 
            // stoInGra
            // 
            this.stoInGra.AutoSize = true;
            this.stoInGra.Location = new System.Drawing.Point(259, 201);
            this.stoInGra.Name = "stoInGra";
            this.stoInGra.Size = new System.Drawing.Size(72, 16);
            this.stoInGra.TabIndex = 34;
            this.stoInGra.Text = "入库报表";
            this.stoInGra.UseVisualStyleBackColor = true;
            // 
            // saleGra
            // 
            this.saleGra.AutoSize = true;
            this.saleGra.Location = new System.Drawing.Point(259, 223);
            this.saleGra.Name = "saleGra";
            this.saleGra.Size = new System.Drawing.Size(72, 16);
            this.saleGra.TabIndex = 35;
            this.saleGra.Text = "销售报表";
            this.saleGra.UseVisualStyleBackColor = true;
            // 
            // stfInfo
            // 
            this.stfInfo.AutoSize = true;
            this.stfInfo.Location = new System.Drawing.Point(414, 75);
            this.stfInfo.Name = "stfInfo";
            this.stfInfo.Size = new System.Drawing.Size(96, 16);
            this.stfInfo.TabIndex = 15;
            this.stfInfo.Text = "员工信息管理";
            this.stfInfo.UseVisualStyleBackColor = true;
            this.stfInfo.Click += new System.EventHandler(this.stfInfo_Click);
            // 
            // commInfo
            // 
            this.commInfo.AutoSize = true;
            this.commInfo.Location = new System.Drawing.Point(259, 75);
            this.commInfo.Name = "commInfo";
            this.commInfo.Size = new System.Drawing.Size(96, 16);
            this.commInfo.TabIndex = 9;
            this.commInfo.Text = "商品信息管理";
            this.commInfo.UseVisualStyleBackColor = true;
            this.commInfo.Click += new System.EventHandler(this.commInfo_Click);
            // 
            // cusInfo
            // 
            this.cusInfo.AutoSize = true;
            this.cusInfo.Location = new System.Drawing.Point(99, 76);
            this.cusInfo.Name = "cusInfo";
            this.cusInfo.Size = new System.Drawing.Size(96, 16);
            this.cusInfo.TabIndex = 3;
            this.cusInfo.Text = "客户信息管理";
            this.cusInfo.UseVisualStyleBackColor = true;
            this.cusInfo.Click += new System.EventHandler(this.cusInfo_Click);
            // 
            // addSale
            // 
            this.addSale.AutoSize = true;
            this.addSale.Location = new System.Drawing.Point(414, 178);
            this.addSale.Name = "addSale";
            this.addSale.Size = new System.Drawing.Size(96, 16);
            this.addSale.TabIndex = 39;
            this.addSale.Text = "添加销售信息";
            this.addSale.UseVisualStyleBackColor = true;
            // 
            // updateStf
            // 
            this.updateStf.AutoSize = true;
            this.updateStf.Location = new System.Drawing.Point(435, 120);
            this.updateStf.Name = "updateStf";
            this.updateStf.Size = new System.Drawing.Size(96, 16);
            this.updateStf.TabIndex = 18;
            this.updateStf.Text = "修改员工信息";
            this.updateStf.UseVisualStyleBackColor = true;
            // 
            // addStf
            // 
            this.addStf.AutoSize = true;
            this.addStf.Location = new System.Drawing.Point(414, 51);
            this.addStf.Name = "addStf";
            this.addStf.Size = new System.Drawing.Size(96, 16);
            this.addStf.TabIndex = 14;
            this.addStf.Text = "添加员工信息";
            this.addStf.UseVisualStyleBackColor = true;
            // 
            // deleteStf
            // 
            this.deleteStf.AutoSize = true;
            this.deleteStf.Location = new System.Drawing.Point(435, 97);
            this.deleteStf.Name = "deleteStf";
            this.deleteStf.Size = new System.Drawing.Size(96, 16);
            this.deleteStf.TabIndex = 16;
            this.deleteStf.Text = "删除员工信息";
            this.deleteStf.UseVisualStyleBackColor = true;
            // 
            // updateComm
            // 
            this.updateComm.AutoSize = true;
            this.updateComm.Location = new System.Drawing.Point(275, 120);
            this.updateComm.Name = "updateComm";
            this.updateComm.Size = new System.Drawing.Size(96, 16);
            this.updateComm.TabIndex = 12;
            this.updateComm.Text = "修改商品信息";
            this.updateComm.UseVisualStyleBackColor = true;
            // 
            // addComm
            // 
            this.addComm.AutoSize = true;
            this.addComm.Location = new System.Drawing.Point(259, 55);
            this.addComm.Name = "addComm";
            this.addComm.Size = new System.Drawing.Size(96, 16);
            this.addComm.TabIndex = 8;
            this.addComm.Text = "添加商品信息";
            this.addComm.UseVisualStyleBackColor = true;
            // 
            // deleteComm
            // 
            this.deleteComm.AutoSize = true;
            this.deleteComm.Location = new System.Drawing.Point(275, 97);
            this.deleteComm.Name = "deleteComm";
            this.deleteComm.Size = new System.Drawing.Size(96, 16);
            this.deleteComm.TabIndex = 10;
            this.deleteComm.Text = "删除商品信息";
            this.deleteComm.UseVisualStyleBackColor = true;
            // 
            // updateCus
            // 
            this.updateCus.AutoSize = true;
            this.updateCus.Location = new System.Drawing.Point(119, 120);
            this.updateCus.Name = "updateCus";
            this.updateCus.Size = new System.Drawing.Size(96, 16);
            this.updateCus.TabIndex = 6;
            this.updateCus.Text = "修改客户信息";
            this.updateCus.UseVisualStyleBackColor = true;
            // 
            // roleManage
            // 
            this.roleManage.AutoSize = true;
            this.roleManage.Location = new System.Drawing.Point(540, 27);
            this.roleManage.Name = "roleManage";
            this.roleManage.Size = new System.Drawing.Size(72, 16);
            this.roleManage.TabIndex = 19;
            this.roleManage.Text = "角色管理";
            this.roleManage.UseVisualStyleBackColor = true;
            this.roleManage.Click += new System.EventHandler(this.roleManage_Click);
            // 
            // verifyCommManage
            // 
            this.verifyCommManage.AutoSize = true;
            this.verifyCommManage.Location = new System.Drawing.Point(540, 156);
            this.verifyCommManage.Name = "verifyCommManage";
            this.verifyCommManage.Size = new System.Drawing.Size(96, 16);
            this.verifyCommManage.TabIndex = 43;
            this.verifyCommManage.Text = "药品检验管理";
            this.verifyCommManage.UseVisualStyleBackColor = true;
            this.verifyCommManage.Click += new System.EventHandler(this.verifyCommManage_Click);
            // 
            // graphManage
            // 
            this.graphManage.AutoSize = true;
            this.graphManage.Location = new System.Drawing.Point(237, 155);
            this.graphManage.Name = "graphManage";
            this.graphManage.Size = new System.Drawing.Size(72, 16);
            this.graphManage.TabIndex = 32;
            this.graphManage.Text = "统计报表";
            this.graphManage.UseVisualStyleBackColor = true;
            this.graphManage.Click += new System.EventHandler(this.graphManage_Click);
            // 
            // saleManage
            // 
            this.saleManage.AutoSize = true;
            this.saleManage.Location = new System.Drawing.Point(392, 155);
            this.saleManage.Name = "saleManage";
            this.saleManage.Size = new System.Drawing.Size(72, 16);
            this.saleManage.TabIndex = 38;
            this.saleManage.Text = "销售管理";
            this.saleManage.UseVisualStyleBackColor = true;
            this.saleManage.Click += new System.EventHandler(this.saleManage_Click);
            // 
            // staffManage
            // 
            this.staffManage.AutoSize = true;
            this.staffManage.Location = new System.Drawing.Point(392, 27);
            this.staffManage.Name = "staffManage";
            this.staffManage.Size = new System.Drawing.Size(72, 16);
            this.staffManage.TabIndex = 13;
            this.staffManage.Text = "员工管理";
            this.staffManage.UseVisualStyleBackColor = true;
            this.staffManage.Click += new System.EventHandler(this.staffManage_Click);
            // 
            // commodityManage
            // 
            this.commodityManage.AutoSize = true;
            this.commodityManage.Location = new System.Drawing.Point(237, 29);
            this.commodityManage.Name = "commodityManage";
            this.commodityManage.Size = new System.Drawing.Size(72, 16);
            this.commodityManage.TabIndex = 7;
            this.commodityManage.Text = "商品管理";
            this.commodityManage.UseVisualStyleBackColor = true;
            this.commodityManage.Click += new System.EventHandler(this.commodityManage_Click);
            // 
            // customerManage
            // 
            this.customerManage.AutoSize = true;
            this.customerManage.Location = new System.Drawing.Point(77, 33);
            this.customerManage.Name = "customerManage";
            this.customerManage.Size = new System.Drawing.Size(72, 16);
            this.customerManage.TabIndex = 1;
            this.customerManage.Text = "客户管理";
            this.customerManage.UseVisualStyleBackColor = true;
            this.customerManage.Click += new System.EventHandler(this.customerManage_Click);
            // 
            // stockManage
            // 
            this.stockManage.AutoSize = true;
            this.stockManage.Location = new System.Drawing.Point(77, 156);
            this.stockManage.Name = "stockManage";
            this.stockManage.Size = new System.Drawing.Size(72, 16);
            this.stockManage.TabIndex = 25;
            this.stockManage.Text = "库存管理";
            this.stockManage.UseVisualStyleBackColor = true;
            this.stockManage.Click += new System.EventHandler(this.stockManage_Click);
            // 
            // selectSale
            // 
            this.selectSale.AutoSize = true;
            this.selectSale.Location = new System.Drawing.Point(414, 200);
            this.selectSale.Name = "selectSale";
            this.selectSale.Size = new System.Drawing.Size(96, 16);
            this.selectSale.TabIndex = 40;
            this.selectSale.Text = "销售信息管理";
            this.selectSale.UseVisualStyleBackColor = true;
            // 
            // reOrder
            // 
            this.reOrder.AutoSize = true;
            this.reOrder.Location = new System.Drawing.Point(414, 222);
            this.reOrder.Name = "reOrder";
            this.reOrder.Size = new System.Drawing.Size(96, 16);
            this.reOrder.TabIndex = 41;
            this.reOrder.Text = "退单信息管理";
            this.reOrder.UseVisualStyleBackColor = true;
            // 
            // addCus
            // 
            this.addCus.AutoSize = true;
            this.addCus.Location = new System.Drawing.Point(99, 55);
            this.addCus.Name = "addCus";
            this.addCus.Size = new System.Drawing.Size(96, 16);
            this.addCus.TabIndex = 2;
            this.addCus.Text = "添加客户信息";
            this.addCus.UseVisualStyleBackColor = true;
            // 
            // deleteCus
            // 
            this.deleteCus.AutoSize = true;
            this.deleteCus.Location = new System.Drawing.Point(119, 98);
            this.deleteCus.Name = "deleteCus";
            this.deleteCus.Size = new System.Drawing.Size(96, 16);
            this.deleteCus.TabIndex = 4;
            this.deleteCus.Text = "删除客户信息";
            this.deleteCus.UseVisualStyleBackColor = true;
            // 
            // reGoods
            // 
            this.reGoods.AutoSize = true;
            this.reGoods.Location = new System.Drawing.Point(414, 244);
            this.reGoods.Name = "reGoods";
            this.reGoods.Size = new System.Drawing.Size(96, 16);
            this.reGoods.TabIndex = 40;
            this.reGoods.Text = "退货信息管理";
            this.reGoods.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(314, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "角色名";
            // 
            // limitList
            // 
            this.Controls.Add(this.gupBox);
            this.Size = new System.Drawing.Size(914, 451);
            this.Text = "权限管理";
            this.gupBox.ResumeLayout(false);
            this.gupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gupBox;
        private System.Windows.Forms.ComboBox roleCob;
        private System.Windows.Forms.Button edeit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox stoWarn;
        private System.Windows.Forms.CheckBox readyStoOut;
        private System.Windows.Forms.CheckBox stoOut;
        private System.Windows.Forms.CheckBox adjustSto;
        private System.Windows.Forms.CheckBox stoIn;
        private System.Windows.Forms.CheckBox selectSto;
        private System.Windows.Forms.CheckBox rolInfo;
        private System.Windows.Forms.CheckBox updateRol;
        private System.Windows.Forms.CheckBox addRol;
        private System.Windows.Forms.CheckBox deleteRol;
        private System.Windows.Forms.CheckBox reGoodsGra;
        private System.Windows.Forms.CheckBox stoOutGra;
        private System.Windows.Forms.CheckBox reOrderGra;
        private System.Windows.Forms.CheckBox stoInGra;
        private System.Windows.Forms.CheckBox saleGra;
        private System.Windows.Forms.CheckBox stfInfo;
        private System.Windows.Forms.CheckBox commInfo;
        private System.Windows.Forms.CheckBox cusInfo;
        private System.Windows.Forms.CheckBox addSale;
        private System.Windows.Forms.CheckBox updateStf;
        private System.Windows.Forms.CheckBox addStf;
        private System.Windows.Forms.CheckBox deleteStf;
        private System.Windows.Forms.CheckBox updateComm;
        private System.Windows.Forms.CheckBox addComm;
        private System.Windows.Forms.CheckBox deleteComm;
        private System.Windows.Forms.CheckBox updateCus;
        private System.Windows.Forms.CheckBox roleManage;
        private System.Windows.Forms.CheckBox verifyCommManage;
        private System.Windows.Forms.CheckBox graphManage;
        private System.Windows.Forms.CheckBox saleManage;
        private System.Windows.Forms.CheckBox staffManage;
        private System.Windows.Forms.CheckBox commodityManage;
        private System.Windows.Forms.CheckBox customerManage;
        private System.Windows.Forms.CheckBox stockManage;
        private System.Windows.Forms.CheckBox selectSale;
        private System.Windows.Forms.CheckBox reOrder;
        private System.Windows.Forms.CheckBox addCus;
        private System.Windows.Forms.CheckBox deleteCus;
        private System.Windows.Forms.CheckBox reGoods;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Label idLab;
        private System.Windows.Forms.Button submitUp;
        private System.Windows.Forms.TextBox tbx;
        private System.Windows.Forms.CheckBox updateVerify;
        private System.Windows.Forms.CheckBox deleteVerify;
        private System.Windows.Forms.CheckBox VerifyInfo;
        private System.Windows.Forms.CheckBox addVerify;
    }
}