﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 医药管理系统.bean
{
    class Sales_class
    {
        public String s1, s2, s3, s4, s5, s6, s7, s8, s9;
    }
}
