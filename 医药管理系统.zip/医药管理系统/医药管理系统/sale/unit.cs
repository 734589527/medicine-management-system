﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 医药管理系统
{
    class unit
    {
        int id;

        public void setId(int id)
        {
            this.id = id;
        }
        public int getId()
        {
            return id;
        }
        String un;
        public void setUn(String un)
        {
            this.un = un;
        }
        public String getUn()
        {
            return un;
        }
    }
}
