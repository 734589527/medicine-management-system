﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace 医药管理系统
{
    public partial class sales_ : DevExpress.XtraReports.UI.XtraReport
    {
        public sales_()
        {
            InitializeComponent();
        }

    }
}
