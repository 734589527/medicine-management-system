﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 医药管理系统
{
    class selected
    {
       public static String[] s=new String[6];
    }
}
